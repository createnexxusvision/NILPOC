I promise to never use my private key associated with real money in plain text.
