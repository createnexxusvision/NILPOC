# Unified Event Schema (NILPOC)

The goal: **one stable event vocabulary** across your whole ecosystem so that:
- SQL indexing is deterministic (no "which contract emitted what?" drift)
- you can replay state from raw logs (event sourcing)
- you can support multiple chains (Sepolia test, Polygon main) without rewriting queries

## Canonical events

All core events live in: `src/core/NILEvents.sol`.

### DealEngine
- `DealCreated(dealId, sponsor, athlete, token, amount, deadline, termsHash)`
- `DealFunded(dealId, funder, token, amount)`
- `DealDelivered(dealId, athlete, evidenceHash, deliveredAt)`
- `DealDisputed(dealId, by, reasonCode, evidenceHash, at)`
- `DealSettled(dealId, token, gross, platformFee, netToAthlete, feeRecipient, at)`
- `DealRefunded(dealId, token, amount, sponsor, at)`

### PayoutRouter
- `SplitDefined(splitId, splitHash, creator)`
- `PayoutExecuted(payoutId, ref, payer, token, amount, splitId, at)`

### DeferredVault
- `GrantCreated(grantId, sponsor, beneficiary, token, amount, unlockTime, termsHash)`
- `GrantAttested(grantId, attester, attestationHash, at)`
- `GrantWithdrawn(grantId, beneficiary, token, amount, at)`
- `GrantRefunded(grantId, sponsor, token, amount, at)`

### ReceiptNFT
- `ReceiptMinted(tokenId, orderHash, buyer, seller, token, price, platformFee, tokenURI)`

## SQL tables

See `db/schema.sql` for:
- `chain_events` raw log store
- `*_current` tables for "latest state" queries

## Indexing rule

**Never** treat `*_current` tables as source of truth. They are derived views.
If you need to rebuild, truncate them and replay from `chain_events`.
